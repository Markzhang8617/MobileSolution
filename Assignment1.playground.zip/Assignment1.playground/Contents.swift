import UIKit

//1
func twoSum(_ a:Int, _ b:Int)-> Double{
    return Double(a+b)
}
var x = 10
var y = 5
let result = twoSum(x,y)
print("The result of twoSum(\(x),\(y)) is \(result)")

//2
func studentExits(in students: [String],name: String) ->Bool{
    return students.contains(name)
}
let students = ["Mark","James","Joy","Hank"]
let test1 = "Mark"
let test2 = "Hanks"
let testResult1 = studentExits(in: students, name: test1)
let testResult2 = studentExits(in: students, name: test2)
print("The result of studentExits(\(students),\(test1)) is \(testResult1)")
print("The result of studentExits(\(students),\(test2)) is \(testResult2)")

//3
func reduce(in Integers: [Int]) ->Int{
    var sum = 0
    for value in 0..<Integers.count {
        sum = sum + Integers[value]
    }
    return sum
}
let Integers = [1,2,3,4,5,6,7]
let reduceResult = reduce(in: Integers)
print("The result of reduce(\(Integers)) is \(reduceResult)")

//4
func calHypotenuse(_ a:Double, _ b:Double)-> Double{
    return sqrt(a*a+b*b)
}
let a1 = 3.0
let b1 = 4.0
let calResult = calHypotenuse(a1, b1)
print("The result of calHypotenuse(\(a1),\(b1)) is \(calResult)")


//5
func match<K,V>(key: K, in dictionary:[K:V]) -> V?{
    return dictionary[key]
}

let dict = ["Apple": 1,"Banana": 2,"Orange": 3]
let key1 = "Apple"
let key2 = "Eggplant"

if let value1 = match(key: key1, in: dict){
    print ("The result of match(\(key1),\(dict)) is \(value1)")
} else {
    print ("The key \(key1) does not exist in \(dict)")
}

if let value2 = match(key: key2, in: dict){
    print ("The result of match(\(key2),\(dict)) is \(value2)")
} else {
    print ("The key \(key2) does not exist in \(dict)")
}
