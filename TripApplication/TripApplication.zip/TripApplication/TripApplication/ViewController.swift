//
//  ViewController.swift
//  TripApplication
//
//  Created by student on 18/8/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

